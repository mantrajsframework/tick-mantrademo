# log Mantra component

Simple logger to add messages of type info, warning and error. It exposes a simple API method to.

# API exposed by log

## async Mantra.api.logs.add( Mantra, options )

Adds a new entry to log.

Paramenters:
* Mantra: Mantra API object
* options: object with the following properties:
    * type: type of the log (values 'info', 'warning' or 'error')
    * description: description of the log entry (string)
    * key: key for the log entry (string, optional)
    * data: detail data of the log (string or object, optional)
    * counter: counter for the key used, used for order entries by concept (integer, optional)

# Sample

```javascript
await Mantra.api.logs.add( Mantra, { type: 'info', description: 'Service started' });
```

# Configuration
log component defines this configuration in mantra.json config file than can be override in mantraconfig.json:

```json
"defaultconfig": {
    "logToConsole": true,
    "daystoremoveoldlogs": 1
}
```

Where:
* logToConsole: true | false. If true, messages are shown to console instead of be stored at the database.
* daystoremoveoldlogs: number of days to leave message en data repository

# Repository model
log component defines a data model described at model/logs.schema.json
