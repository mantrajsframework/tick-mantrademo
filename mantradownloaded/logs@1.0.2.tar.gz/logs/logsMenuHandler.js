"use strict";

module.exports = {
    ShowLogs: async (MantraAPI) => {
        return [
            {
                href: "/logs/showlogs",
                text: "Logs",
                icon: "fa-lock",
                weight: 1000
            }
        ];
    }
}