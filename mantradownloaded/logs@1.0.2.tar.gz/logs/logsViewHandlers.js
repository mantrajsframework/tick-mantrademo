"use strict";

const LogsRepository = require("./logsRepository");

const PAGESIZE_LOGS_VIEW = 50;

module.exports = {
    ShowLogs: async (req,res) => {
        const Mantra = res.MantraAPI;

        await Mantra.api.pager.renderpage( Mantra, {
            pageSize: PAGESIZE_LOGS_VIEW,
            componentName: "logs",
            componentCommand: "showlogs",
            getItemsCount: async () => { return LogsRepository.GetCount(Mantra); },
            noItems: async () => {
                return Mantra.Invoke("messageview.showgeneralmessage", {
                    headermessage: "No hay logs",
                    messagecontent: "No hay entradas de logs que mostrar"
                });    
            },
            getItemsPaged: async (start, pageSize) => {
                return LogsRepository.GetPaged( Mantra, start, pageSize );
            },
            translateItems: async (items) => {
                return Mantra.Invoke("date.formatbyproperty", { entities: items, property: "created" } );
            },
            itemTemplateRow: "logs/logrow"
        });
    }
}