"use strict";

const LogsApiHandlers = require("./logsApiHandlers");
const LogsEventHandlers = require("./logsEventHandlers");
const LogsMenuHandler = require("./logsMenuHandler");
const LogsViewHandlers = require("./logsViewHandlers");

class LogsStarter {
    async onStart(MantraAPI) {
        MantraAPI.Hooks("logs")
            .Api([{
                APIName: "add",
                APIHandler: LogsApiHandlers.Add
            }, {
                APIName: "getbykey",
                APIHandler: LogsApiHandlers.GetByKey
            }])
            .Event([{
                EventName: "system.cleanup",
                EventHandler: LogsEventHandlers.SystemCleanup
            }])
            .View([{
                Command: "showlogs",
                Handler: LogsViewHandlers.ShowLogs,
                AccessCondition: ["system.islogged", "admin.isuseradmincheck", "pager.checkfirstpage"]
            }])
            .Extend( {
                Type: "hdlmenu",
                Name: "menu",
                MenuHandler: LogsMenuHandler.ShowLogs,
                IsNotLoggedMenu: false,
                IsUserMenu: false,
                IsAdminMenu: true
            })
    }
}

class LogsInstallation {
    async onInstall(MantraAPI) {
        return MantraAPI.InstallSchema( "logs" );
    }

    async onUninstall(MantraAPI) {
        return MantraAPI.UninstallSchema( "logs" );
    }
}

module.exports = () => {
    return {
        Start: new LogsStarter(),
        Install: new LogsInstallation()
    };
}