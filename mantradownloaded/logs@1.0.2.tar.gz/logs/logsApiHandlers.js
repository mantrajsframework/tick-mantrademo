"use strict";

let _ = require("underscore");
let LogsRepository = require("./logsRepository");

module.exports = {
    /*
     * API logs.add
     * Adds a new entry in logs
     * Params:
     *    data.type: <type of log, value in 'info', 'error', 'warning'>
     *    data.key: <key for the log entry, specific id for the log, optional>,
     *    data.counter: <counter for the key used, used for order entries by concept, optional>,
     *    data.description: <description of the log entry>
     *    data.data: <detail data of the log, can be a string of an object>
     */
    Add: async (MantraAPI, data) => {
        if ( data.type != 'info' && data.type != 'error' && data.type != 'warning' ) {
            throw Error(`Invalid log type of ${data.type}`);
        }

        let logToConsole = MantraAPI.GetComponentConfig("logs").logToConsole == true;
        let logData = "";
        let logKey = data.key ? data.key : "";
        let logCounter = data.counter ? data.counter: 0;

        if ( logToConsole ) {
            console.log(new Date(), data.type, data.description, data.data );
        }

        if ( typeof data.data == 'object' && _.isEmpty(data.data) == false ) {
            logData = JSON.stringify(logData);
        }

        return LogsRepository.Add( MantraAPI, data.type, logKey, logCounter, data.description, logData );        
    },

    /*
     * API logs.getbykey
     * Return all logs entry for a given key (field logkey in entities)
     * The entities are returned order by created field descendingly
     */
    GetByKey: async (MantraAPI, logKey) => {
        return LogsRepository.GetByKey(MantraAPI, logKey);
    }
}