"use strict";

module.exports = {
    Add: async (MantraAPI, type, key, counter, description, data ) => {
        let db = MantraAPI.ComponentEntities("logs").logs;

        return db.I().V( { logtype: type, logkey: key, logcounter: counter, logdescription: description, logdata: data } ).R();
    },

    GetCount: async (MantraAPI) => {
        let db = MantraAPI.ComponentEntities("logs").logs;

        return db.S().C();
    },

    GetPaged: async (MantraAPI, start, end) => {
        let db = MantraAPI.ComponentEntities("logs").logs;

        return db.S().OB("created",false).L(start,end).R();
    },

    GetOlderLogs: async (MantraAPI, date) => {
        let db = MantraAPI.ComponentEntities("logs").logs;
        let result = await db.S("ID").W("created < ?", date).R();

        return MantraAPI.Utils.Underscore.map( result, (item) => item.ID );
    },

    RemoveById: async (MantraAPI, logId ) => {
        return MantraAPI.ComponentEntities("logs").logs.D().DeleteById(logId);
    },

    GetByKey: async (MantraAPI, logKey) => {
        return MantraAPI.ComponentEntities("logs").logs.S().W("logkey=?",logKey).OB("created",false).R();
    }
}