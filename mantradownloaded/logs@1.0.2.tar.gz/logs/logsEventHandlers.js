"use strict";

module.exports = {
    SystemCleanup: async (eventData) => {
        try {
            let api = eventData.MantraAPI;

            let removedCount = await api.Invoke("dbremoveolder.remove", {
                entities: api.ComponentEntities("logs").logs,
                seconds: api.GetComponentConfig("logs").daystoremoveoldlogs * 24 * 60 * 60
            });

            await api.LogInfo(`Removed from logs ${removedCount} old rows`);
        } catch(err){
            await eventData.MantraAPI.LogError("Error when removing old logs", err);
        }
    }
}